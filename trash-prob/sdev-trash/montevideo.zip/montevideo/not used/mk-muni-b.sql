\a
\f ' '
\t
\o muni-b.containers.txt
select gid,2,st_x(geom),st_y(geom),capacidad,0,360,2 from contenedores_geom a where left(a.cod_recorr,1)='B' order by gid;
\o
\o muni-b.dmatrix-meters.txt
select * from distance_matrix_b order by nfrom, nto asc;
\o
\o muni-b.dmatrix-time.txt
-- select * from distance_matrix_b order by nfrom, nto asc;
-- convert distances to time in minutes
--select nfrom, nto, case when dist>880 then dist/833 else dist/440 end from distance_matrix_b order by nfrom, nto asc;
select nfrom, nto, ttime from osrm_ttime order by id;
\o
\o muni-b.depots.txt
select -1,0,st_x(st_transform(st_setsrid(st_makepoint(-56.1241, -34.89773), 4326), 32721)),st_y(st_transform(st_setsrid(st_makepoint(-56.1241, -34.89773), 4326), 32721)),0,0,14400,0 union all select -2,0,st_x(st_transform(st_setsrid(st_makepoint(-56.21662, -34.848845), 4326), 32721)),st_y(st_transform(st_setsrid(st_makepoint(-56.21662, -34.848845), 4326), 32721)),0,0,14400,0;
\o
\o muni-b.dumps.txt
select -3,1,st_x(st_transform(st_setsrid(st_makepoint(-56.094837, -34.848821), 4326), 32721)),st_y(st_transform(st_setsrid(st_makepoint(-56.094837, -34.848821), 4326), 32721)),0,0,14400,20;
\o
